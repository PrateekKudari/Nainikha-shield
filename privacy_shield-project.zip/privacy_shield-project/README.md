# Nainikha-shield



cd privacy_shield_deploy
dir
python app.py