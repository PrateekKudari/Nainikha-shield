#define MyAppName "Nainikha"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Prateek Kudari"
#define MyAppExeName "Nainikha.exe"

[Setup]
AppId={{8B8B7C91-7D6D-4B7A-9C32-5A7D9E1B4C20}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}

DefaultDirName={autopf}\Nainikha
DefaultGroupName=Nainikha

OutputDir=installer
OutputBaseFilename=Nainikha-Setup

Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Files]
Source: "C:\Users\Lenovo\OneDrive\Videos\privacy_shield_deploy\privacy_shield_deploy\dist\Nainikha\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autodesktop}\Nainikha"; Filename: "{app}\Nainikha.exe"; WorkingDir: "{app}"
Name: "{group}\Nainikha"; Filename: "{app}\Nainikha.exe"; WorkingDir: "{app}"

[Run]
Filename: "{app}\Nainikha.exe"; Description: "Launch Nainikha"; Flags: nowait postinstall skipifsilent